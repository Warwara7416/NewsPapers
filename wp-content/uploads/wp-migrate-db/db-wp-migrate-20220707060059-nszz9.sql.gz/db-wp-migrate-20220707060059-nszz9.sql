# WordPress MySQL database migration
#
# Generated: Thursday 7. July 2022 06:00 UTC
# Hostname: localhost
# Database: `db-wp`
# URL: //localhost/warwara.first_stage.local
# Path: \\\\EDU.LOCAL\\PUBLIC\\studenthomes\\20300826\\My Documents\\uwamp\\www\\warwara.first_stage.local
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, page, post, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2022-07-06 08:53:00', '2022-07-06 05:53:00', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0),
(2, 1, 'Грубая Сила', 'pavel.002@mail.ru', 'http://localhost/warwara.first_stage.local', '::1', '2022-07-06 09:25:02', '2022-07-06 06:25:02', 'Привет, снежинки.\r\n-- Отдел грубой силы.', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'comment', 0, 1) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/warwara.first_stage.local', 'yes'),
(2, 'home', 'http://localhost/warwara.first_stage.local', 'yes'),
(3, 'blogname', 'НОВОСТНОЙ ОТДЕЛ', 'yes'),
(4, 'blogdescription', 'Риторика и драма в одном флаконе', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'pavel.002@mail.ru', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'quality', 'yes'),
(41, 'stylesheet', 'mazino', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '51917', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:3:{i:2;a:4:{s:5:"title";s:13:"О сайте";s:4:"text";s:205:"Здесь может быть отличное место для того, чтобы представить себя, свой сайт или выразить какие-то благодарности.";s:6:"filter";b:1;s:6:"visual";b:1;}i:3;a:4:{s:5:"title";s:21:"Найдите нас";s:4:"text";s:226:"<strong>Адрес</strong>\n123 Мейн стрит\nНью Йорк, NY 10001\n\n<strong>Часы</strong>\nПонедельник&mdash;пятница: 9:00&ndash;17:00\nСуббота и воскресенье: 11:00&ndash;15:00";s:6:"filter";b:1;s:6:"visual";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1672638780', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:2:{i:0;s:6:"text-2";i:1;s:6:"text-3";}s:15:"sidebar-primary";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:18:"footer-widget-area";a:0:{}s:11:"woocommerce";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:8:{i:1657176861;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1657216461;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1657216483;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1657259681;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1657259683;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1657259687;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1657778060;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(109, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(129, 'theme_mods_twentytwentytwo', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1657092848;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:2:{i:0;s:6:"text-2";i:1;s:6:"text-3";}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(135, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}}', 'yes'),
(162, 'recovery_keys', 'a:0:{}', 'yes'),
(163, 'can_compress_scripts', '1', 'no'),
(179, 'finished_updating_comment_type', '1', 'yes'),
(191, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(192, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(195, 'theme_mods_twentytwenty', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1657087769;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:2:{i:0;s:6:"text-2";i:1;s:6:"text-3";}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(200, 'current_theme', 'Mazino', 'yes'),
(201, 'theme_switched', '', 'yes'),
(231, 'category_children', 'a:1:{i:3;a:1:{i:0;i:4;}}', 'yes'),
(244, 'recently_activated', 'a:0:{}', 'yes'),
(257, 'theme_mods_mazino', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(264, 'quality_customizer_notify_show_recommended_plugins', 'a:1:{s:17:"webriti-companion";b:1;}', 'yes'),
(306, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1657173659;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_edit_lock', '1657089051:1'),
(4, 6, '_wp_attached_file', '2022/07/2020-landscape-1.png'),
(5, 6, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:769;s:4:"file";s:28:"2022/07/2020-landscape-1.png";s:8:"filesize";i:1211;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:28:"2020-landscape-1-300x192.png";s:5:"width";i:300;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1251;}s:5:"large";a:5:{s:4:"file";s:29:"2020-landscape-1-1024x656.png";s:5:"width";i:1024;s:6:"height";i:656;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71908;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"2020-landscape-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14329;}s:12:"medium_large";a:5:{s:4:"file";s:28:"2020-landscape-1-768x492.png";s:5:"width";i:768;s:6:"height";i:492;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:22328;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(6, 6, '_starter_content_theme', 'twentytwenty'),
(7, 6, '_customize_draft_post_name', '%d0%be%d0%b1%d0%bd%d0%be%d0%b2%d0%bb%d1%91%d0%bd%d0%bd%d0%b0%d1%8f-umoma-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d0%b2%d0%b0%d0%b5%d1%82-%d0%b4%d0%b2%d0%b5%d1%80%d0%b8'),
(8, 7, '_thumbnail_id', '6'),
(9, 7, '_customize_draft_post_name', 'umoma-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d0%b2%d0%b0%d0%b5%d1%82-%d0%b4%d0%b2%d0%b5%d1%80%d0%b8'),
(10, 7, '_customize_changeset_uuid', '7efed5fe-7d2c-42ac-9c81-da402b7d4268'),
(11, 8, '_customize_draft_post_name', '%d0%be-%d0%bd%d0%b0%d1%81'),
(12, 8, '_customize_changeset_uuid', '7efed5fe-7d2c-42ac-9c81-da402b7d4268'),
(13, 9, '_customize_draft_post_name', '%d0%ba%d0%be%d0%bd%d1%82%d0%b0%d0%ba%d1%82%d1%8b'),
(14, 9, '_customize_changeset_uuid', '7efed5fe-7d2c-42ac-9c81-da402b7d4268'),
(15, 10, '_customize_draft_post_name', '%d0%b1%d0%bb%d0%be%d0%b3'),
(16, 10, '_customize_changeset_uuid', '7efed5fe-7d2c-42ac-9c81-da402b7d4268'),
(17, 12, '_wp_attached_file', '2022/07/2020-landscape-1-1.png'),
(18, 12, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:769;s:4:"file";s:30:"2022/07/2020-landscape-1-1.png";s:8:"filesize";i:1211;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:30:"2020-landscape-1-1-300x192.png";s:5:"width";i:300;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1251;}s:5:"large";a:5:{s:4:"file";s:31:"2020-landscape-1-1-1024x656.png";s:5:"width";i:1024;s:6:"height";i:656;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71908;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"2020-landscape-1-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14329;}s:12:"medium_large";a:5:{s:4:"file";s:30:"2020-landscape-1-1-768x492.png";s:5:"width";i:768;s:6:"height";i:492;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:22328;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(19, 12, '_starter_content_theme', 'twentytwenty'),
(20, 12, '_customize_draft_post_name', '%d0%be%d0%b1%d0%bd%d0%be%d0%b2%d0%bb%d1%91%d0%bd%d0%bd%d0%b0%d1%8f-umoma-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d0%b2%d0%b0%d0%b5%d1%82-%d0%b4%d0%b2%d0%b5%d1%80%d0%b8'),
(21, 13, '_thumbnail_id', '12'),
(22, 13, '_customize_draft_post_name', 'umoma-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d0%b2%d0%b0%d0%b5%d1%82-%d0%b4%d0%b2%d0%b5%d1%80%d0%b8'),
(23, 13, '_customize_changeset_uuid', 'c599b434-e0c8-40da-b7e3-c06714dd7886'),
(24, 14, '_customize_draft_post_name', '%d0%be-%d0%bd%d0%b0%d1%81'),
(25, 14, '_customize_changeset_uuid', 'c599b434-e0c8-40da-b7e3-c06714dd7886'),
(26, 15, '_customize_draft_post_name', '%d0%ba%d0%be%d0%bd%d1%82%d0%b0%d0%ba%d1%82%d1%8b'),
(27, 15, '_customize_changeset_uuid', 'c599b434-e0c8-40da-b7e3-c06714dd7886'),
(28, 16, '_customize_draft_post_name', '%d0%b1%d0%bb%d0%be%d0%b3'),
(29, 16, '_customize_changeset_uuid', 'c599b434-e0c8-40da-b7e3-c06714dd7886'),
(30, 11, '_customize_restore_dismissed', '1'),
(35, 17, '_customize_restore_dismissed', '1'),
(36, 20, '_edit_lock', '1657092930:1'),
(37, 20, '_wp_trash_meta_status', 'publish'),
(38, 20, '_wp_trash_meta_time', '1657092948') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-07-06 08:53:00', '2022-07-06 05:53:00', '<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"fontSize":"small"} -->\n<p class="has-small-font-size" style="font-style:normal;font-weight:600">Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Нашествие мертвецов!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2022-07-06 09:32:57', '2022-07-06 06:32:57', '', 0, 'http://localhost/warwara.first_stage.local/?p=1', 0, 'post', '', 2),
(2, 1, '2022-07-06 08:53:00', '2022-07-06 05:53:00', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href="http://localhost/warwara.first_stage.local/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2022-07-06 08:53:00', '2022-07-06 05:53:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-07-06 08:53:00', '2022-07-06 05:53:00', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://localhost/warwara.first_stage.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-07-06 08:53:00', '2022-07-06 05:53:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-07-06 08:54:47', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-07-06 08:54:47', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?p=4', 0, 'post', '', 0),
(5, 1, '2022-07-06 09:00:09', '2022-07-06 06:00:09', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentytwo', '', '', '2022-07-06 09:00:09', '2022-07-06 06:00:09', '', 0, 'http://localhost/warwara.first_stage.local/?p=5', 0, 'wp_global_styles', '', 0),
(6, 1, '2022-07-06 09:01:50', '0000-00-00 00:00:00', '', 'Обновлённая UMoMA открывает двери', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2022-07-06 09:01:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/wp-content/uploads/2022/07/2020-landscape-1.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2022-07-06 09:01:50', '0000-00-00 00:00:00', '<!-- wp:group {"align":"wide"} --><div class="wp-block-group alignwide"><div class="wp-block-group__inner-container"><!-- wp:heading {"align":"center"} --><h2 class="has-text-align-center">Первоклассное место для современного искусства в северной Швеции. Открыто с 10:00 до 18:00, ежедневно в летние месяцы.</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:columns {"align":"wide"} --><div class="wp-block-columns alignwide"><!-- wp:column --><div class="wp-block-column"><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-1.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>Дни работы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 августа - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-3.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>Театр действий</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 октября - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-2.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>Жизнь которую вы заслужили</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 августа - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-4.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>От Синьяка до Матисса</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 октября - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --></div><!-- /wp:columns --><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-landscape-2.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:group {"align":"wide"} --><div class="wp-block-group alignwide"><div class="wp-block-group__inner-container"><!-- wp:heading {"align":"center","textColor":"accent"} --><h2 class="has-accent-color has-text-align-center">"Киборги, как установила философ Донна Харауэй, не почтительны. Они не помнят космос."</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:paragraph {"dropCap":true} --><p class="has-drop-cap">На семи этажах потрясающей архитектуры UMoMA представляет выставку международного современного искусства, иногда наряду с историческими ретроспективами искусства. Экзистенциальные, политические и философские проблемы являются неотъемлемой частью нашей программы. В качестве посетителя вы приглашены на экскурсии, выступления артистов, лекции, показы фильмов и другие мероприятия с бесплатным входом.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Выставки проводятся UMoMA в сотрудничестве с художниками и музеями по всему миру, они часто привлекают международное внимание. UMoMA получили специальную награду от Европейского музея года и вошли в число лучших кандидатов на премию «Шведский музей года», а также на приз музея Совета Европы.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- wp:group {"customBackgroundColor":"#ffffff","align":"wide"} --><div class="wp-block-group alignwide has-background" style="background-color:#ffffff"><div class="wp-block-group__inner-container"><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:heading {"align":"center"} --><h2 class="has-text-align-center">Вступайте и получайте эксклюзивные предложения!</h2><!-- /wp:heading --><!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">Члены клуба получают доступ к эксклюзивным выставкам и продажам. Оплата членства ежегодно, 99.99$</p><!-- /wp:paragraph --><!-- wp:button {"align":"center"} --><div class="wp-block-button aligncenter"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Вступайте в клуб</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div></div><!-- /wp:group --><!-- wp:gallery {"ids":[39,38],"align":"wide"} --><figure class="wp-block-gallery alignwide columns-2 is-cropped"><ul class="blocks-gallery-grid"><li class="blocks-gallery-item"><figure><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-2.png" alt="" data-id="39" data-full-url="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-2.png" data-link="assets/images/2020-square-2/" class="wp-image-39"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-1.png" alt="" data-id="38" data-full-url="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-1.png" data-link="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-1/" class="wp-image-38"/></figure></li></ul></figure><!-- /wp:gallery -->', 'UMoMA открывает двери', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:01:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-07-06 09:01:50', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>Вы можете быть художником, который желает здесь представить себя и свои работы или представителем бизнеса с описанием миссии.</p>\n<!-- /wp:paragraph -->', 'О нас', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:01:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=8', 0, 'page', '', 0),
(9, 1, '2022-07-06 09:01:50', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>Это страница с основной контактной информацией, такой как адрес и номер телефона. Вы также можете попробовать добавить форму контактов с помощью плагина.</p>\n<!-- /wp:paragraph -->', 'Контакты', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:01:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=9', 0, 'page', '', 0),
(10, 1, '2022-07-06 09:01:50', '0000-00-00 00:00:00', '', 'Блог', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:01:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=10', 0, 'page', '', 0),
(11, 1, '2022-07-06 09:01:50', '0000-00-00 00:00:00', '{"widget_text[2]":{"starter_content":true,"value":{"encoded_serialized_instance":"YTo0OntzOjU6InRpdGxlIjtzOjEzOiLQniDRgdCw0LnRgtC1IjtzOjQ6InRleHQiO3M6MjA1OiLQl9C00LXRgdGMINC80L7QttC10YIg0LHRi9GC0Ywg0L7RgtC70LjRh9C90L7QtSDQvNC10YHRgtC+INC00LvRjyDRgtC+0LPQviwg0YfRgtC+0LHRiyDQv9GA0LXQtNGB0YLQsNCy0LjRgtGMINGB0LXQsdGPLCDRgdCy0L7QuSDRgdCw0LnRgiDQuNC70Lgg0LLRi9GA0LDQt9C40YLRjCDQutCw0LrQuNC1LdGC0L4g0LHQu9Cw0LPQvtC00LDRgNC90L7RgdGC0LguIjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==","title":"\\u041e \\u0441\\u0430\\u0439\\u0442\\u0435","is_widget_customizer_js_value":true,"instance_hash_key":"13f57045f3f458f6694478d8dbace918"},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"sidebars_widgets[sidebar-1]":{"starter_content":true,"value":["text-2"],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"widget_text[3]":{"starter_content":true,"value":{"encoded_serialized_instance":"YTo0OntzOjU6InRpdGxlIjtzOjIxOiLQndCw0LnQtNC40YLQtSDQvdCw0YEiO3M6NDoidGV4dCI7czoyMjY6IjxzdHJvbmc+0JDQtNGA0LXRgTwvc3Ryb25nPgoxMjMg0JzQtdC50L0g0YHRgtGA0LjRggrQndGM0Y4g0JnQvtGA0LosIE5ZIDEwMDAxCgo8c3Ryb25nPtCn0LDRgdGLPC9zdHJvbmc+CtCf0L7QvdC10LTQtdC70YzQvdC40LombWRhc2g70L\\/Rj9GC0L3QuNGG0LA6IDk6MDAmbmRhc2g7MTc6MDAK0KHRg9Cx0LHQvtGC0LAg0Lgg0LLQvtGB0LrRgNC10YHQtdC90YzQtTogMTE6MDAmbmRhc2g7MTU6MDAiO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9","title":"\\u041d\\u0430\\u0439\\u0434\\u0438\\u0442\\u0435 \\u043d\\u0430\\u0441","is_widget_customizer_js_value":true,"instance_hash_key":"bad558930cd1570c2ab23c221f105962"},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"sidebars_widgets[sidebar-2]":{"starter_content":true,"value":["text-3"],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menus_created_posts":{"starter_content":true,"value":[6,7,8,9,10],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu[-1]":{"starter_content":true,"value":{"name":"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435"},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-1]":{"starter_content":true,"value":{"type":"custom","title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u0430\\u044f \\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430","url":"http:\\/\\/localhost\\/warwara.first_stage.local\\/","position":0,"nav_menu_term_id":-1,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-2]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":8,"position":1,"nav_menu_term_id":-1,"title":"\\u041e \\u043d\\u0430\\u0441"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-3]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":10,"position":2,"nav_menu_term_id":-1,"title":"\\u0411\\u043b\\u043e\\u0433"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-4]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":9,"position":3,"nav_menu_term_id":-1,"title":"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"twentytwenty::nav_menu_locations[primary]":{"starter_content":true,"value":-1,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu[-5]":{"starter_content":true,"value":{"name":"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435"},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-5]":{"starter_content":true,"value":{"type":"custom","title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u0430\\u044f \\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430","url":"http:\\/\\/localhost\\/warwara.first_stage.local\\/","position":0,"nav_menu_term_id":-5,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-6]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":8,"position":1,"nav_menu_term_id":-5,"title":"\\u041e \\u043d\\u0430\\u0441"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-7]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":10,"position":2,"nav_menu_term_id":-5,"title":"\\u0411\\u043b\\u043e\\u0433"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-8]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":9,"position":3,"nav_menu_term_id":-5,"title":"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"twentytwenty::nav_menu_locations[expanded]":{"starter_content":true,"value":-5,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu[-9]":{"starter_content":true,"value":{"name":"\\u041c\\u0435\\u043d\\u044e \\u0441\\u043e\\u0446\\u0438\\u0430\\u043b\\u044c\\u043d\\u044b\\u0445 \\u0441\\u0441\\u044b\\u043b\\u043e\\u043a"},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-9]":{"starter_content":true,"value":{"title":"Yelp","url":"https:\\/\\/www.yelp.com","position":0,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-10]":{"starter_content":true,"value":{"title":"Facebook","url":"https:\\/\\/www.facebook.com\\/wordpress","position":1,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-11]":{"starter_content":true,"value":{"title":"Twitter","url":"https:\\/\\/twitter.com\\/wordpress","position":2,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-12]":{"starter_content":true,"value":{"title":"Instagram","url":"https:\\/\\/www.instagram.com\\/explore\\/tags\\/wordcamp\\/","position":3,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"nav_menu_item[-13]":{"starter_content":true,"value":{"title":"Email","url":"mailto:wordpress@example.com","position":4,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"twentytwenty::nav_menu_locations[social]":{"starter_content":true,"value":-9,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"show_on_front":{"starter_content":true,"value":"page","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"page_on_front":{"starter_content":true,"value":7,"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"page_for_posts":{"starter_content":true,"value":10,"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"},"old_sidebars_widgets_data":{"value":{"wp_inactive_widgets":[],"sidebar-1":["text-2"],"sidebar-2":["text-3"]},"type":"global_variable","user_id":1,"date_modified_gmt":"2022-07-06 06:01:50"}}', '', '', 'auto-draft', 'closed', 'closed', '', '7efed5fe-7d2c-42ac-9c81-da402b7d4268', '', '', '2022-07-06 09:01:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?p=11', 0, 'customize_changeset', '', 0),
(12, 1, '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 'Обновлённая UMoMA открывает двери', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2022-07-06 09:08:51', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/wp-content/uploads/2022/07/2020-landscape-1-1.png', 0, 'attachment', 'image/png', 0),
(13, 1, '2022-07-06 09:08:52', '0000-00-00 00:00:00', '<!-- wp:group {"align":"wide"} --><div class="wp-block-group alignwide"><div class="wp-block-group__inner-container"><!-- wp:heading {"align":"center"} --><h2 class="has-text-align-center">Первоклассное место для современного искусства в северной Швеции. Открыто с 10:00 до 18:00, ежедневно в летние месяцы.</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:columns {"align":"wide"} --><div class="wp-block-columns alignwide"><!-- wp:column --><div class="wp-block-column"><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-1.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>Дни работы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 августа - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-3.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>Театр действий</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 октября - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --><!-- wp:column --><div class="wp-block-column"><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-2.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>Жизнь которую вы заслужили</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 августа - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-4.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:heading {"level":3} --><h3>От Синьяка до Матисса</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 октября - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --></div><!-- /wp:columns --><!-- wp:image {"align":"full","id":37,"sizeSlug":"full"} --><figure class="wp-block-image alignfull size-full"><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-landscape-2.png" alt="" class="wp-image-37"/></figure><!-- /wp:image --><!-- wp:group {"align":"wide"} --><div class="wp-block-group alignwide"><div class="wp-block-group__inner-container"><!-- wp:heading {"align":"center","textColor":"accent"} --><h2 class="has-accent-color has-text-align-center">"Киборги, как установила философ Донна Харауэй, не почтительны. Они не помнят космос."</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:paragraph {"dropCap":true} --><p class="has-drop-cap">На семи этажах потрясающей архитектуры UMoMA представляет выставку международного современного искусства, иногда наряду с историческими ретроспективами искусства. Экзистенциальные, политические и философские проблемы являются неотъемлемой частью нашей программы. В качестве посетителя вы приглашены на экскурсии, выступления артистов, лекции, показы фильмов и другие мероприятия с бесплатным входом.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Выставки проводятся UMoMA в сотрудничестве с художниками и музеями по всему миру, они часто привлекают международное внимание. UMoMA получили специальную награду от Европейского музея года и вошли в число лучших кандидатов на премию «Шведский музей года», а также на приз музея Совета Европы.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- wp:group {"customBackgroundColor":"#ffffff","align":"wide"} --><div class="wp-block-group alignwide has-background" style="background-color:#ffffff"><div class="wp-block-group__inner-container"><!-- wp:group --><div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:heading {"align":"center"} --><h2 class="has-text-align-center">Вступайте и получайте эксклюзивные предложения!</h2><!-- /wp:heading --><!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">Члены клуба получают доступ к эксклюзивным выставкам и продажам. Оплата членства ежегодно, 99.99$</p><!-- /wp:paragraph --><!-- wp:button {"align":"center"} --><div class="wp-block-button aligncenter"><a class="wp-block-button__link" href="https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/">Вступайте в клуб</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div></div><!-- /wp:group --><!-- wp:gallery {"ids":[39,38],"align":"wide"} --><figure class="wp-block-gallery alignwide columns-2 is-cropped"><ul class="blocks-gallery-grid"><li class="blocks-gallery-item"><figure><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-2.png" alt="" data-id="39" data-full-url="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-2.png" data-link="assets/images/2020-square-2/" class="wp-image-39"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-1.png" alt="" data-id="38" data-full-url="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-1.png" data-link="http://localhost/warwara.first_stage.local/wp-content/themes/twentytwenty/assets/images/2020-square-1/" class="wp-image-38"/></figure></li></ul></figure><!-- /wp:gallery -->', 'UMoMA открывает двери', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=13', 0, 'page', '', 0),
(14, 1, '2022-07-06 09:08:52', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>Вы можете быть художником, который желает здесь представить себя и свои работы или представителем бизнеса с описанием миссии.</p>\n<!-- /wp:paragraph -->', 'О нас', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=14', 0, 'page', '', 0),
(15, 1, '2022-07-06 09:08:52', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>Это страница с основной контактной информацией, такой как адрес и номер телефона. Вы также можете попробовать добавить форму контактов с помощью плагина.</p>\n<!-- /wp:paragraph -->', 'Контакты', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=15', 0, 'page', '', 0),
(16, 1, '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 'Блог', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?page_id=16', 0, 'page', '', 0),
(17, 1, '2022-07-06 09:08:52', '0000-00-00 00:00:00', '{"widget_text[4]":{"starter_content":true,"value":{"encoded_serialized_instance":"YTo0OntzOjU6InRpdGxlIjtzOjEzOiLQniDRgdCw0LnRgtC1IjtzOjQ6InRleHQiO3M6MjA1OiLQl9C00LXRgdGMINC80L7QttC10YIg0LHRi9GC0Ywg0L7RgtC70LjRh9C90L7QtSDQvNC10YHRgtC+INC00LvRjyDRgtC+0LPQviwg0YfRgtC+0LHRiyDQv9GA0LXQtNGB0YLQsNCy0LjRgtGMINGB0LXQsdGPLCDRgdCy0L7QuSDRgdCw0LnRgiDQuNC70Lgg0LLRi9GA0LDQt9C40YLRjCDQutCw0LrQuNC1LdGC0L4g0LHQu9Cw0LPQvtC00LDRgNC90L7RgdGC0LguIjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==","title":"\\u041e \\u0441\\u0430\\u0439\\u0442\\u0435","is_widget_customizer_js_value":true,"instance_hash_key":"13f57045f3f458f6694478d8dbace918"},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"sidebars_widgets[sidebar-1]":{"starter_content":true,"value":["text-4"],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"widget_text[5]":{"starter_content":true,"value":{"encoded_serialized_instance":"YTo0OntzOjU6InRpdGxlIjtzOjIxOiLQndCw0LnQtNC40YLQtSDQvdCw0YEiO3M6NDoidGV4dCI7czoyMjY6IjxzdHJvbmc+0JDQtNGA0LXRgTwvc3Ryb25nPgoxMjMg0JzQtdC50L0g0YHRgtGA0LjRggrQndGM0Y4g0JnQvtGA0LosIE5ZIDEwMDAxCgo8c3Ryb25nPtCn0LDRgdGLPC9zdHJvbmc+CtCf0L7QvdC10LTQtdC70YzQvdC40LombWRhc2g70L\\/Rj9GC0L3QuNGG0LA6IDk6MDAmbmRhc2g7MTc6MDAK0KHRg9Cx0LHQvtGC0LAg0Lgg0LLQvtGB0LrRgNC10YHQtdC90YzQtTogMTE6MDAmbmRhc2g7MTU6MDAiO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9","title":"\\u041d\\u0430\\u0439\\u0434\\u0438\\u0442\\u0435 \\u043d\\u0430\\u0441","is_widget_customizer_js_value":true,"instance_hash_key":"bad558930cd1570c2ab23c221f105962"},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"sidebars_widgets[sidebar-2]":{"starter_content":true,"value":["text-5"],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menus_created_posts":{"starter_content":true,"value":[12,13,14,15,16],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu[-1]":{"starter_content":true,"value":{"name":"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435"},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-1]":{"starter_content":true,"value":{"type":"custom","title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u0430\\u044f \\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430","url":"http:\\/\\/localhost\\/warwara.first_stage.local\\/","position":0,"nav_menu_term_id":-1,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-2]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":14,"position":1,"nav_menu_term_id":-1,"title":"\\u041e \\u043d\\u0430\\u0441"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-3]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":16,"position":2,"nav_menu_term_id":-1,"title":"\\u0411\\u043b\\u043e\\u0433"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-4]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":15,"position":3,"nav_menu_term_id":-1,"title":"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"twentytwenty::nav_menu_locations[primary]":{"starter_content":true,"value":-1,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu[-5]":{"starter_content":true,"value":{"name":"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435"},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-5]":{"starter_content":true,"value":{"type":"custom","title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u0430\\u044f \\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430","url":"http:\\/\\/localhost\\/warwara.first_stage.local\\/","position":0,"nav_menu_term_id":-5,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-6]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":14,"position":1,"nav_menu_term_id":-5,"title":"\\u041e \\u043d\\u0430\\u0441"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-7]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":16,"position":2,"nav_menu_term_id":-5,"title":"\\u0411\\u043b\\u043e\\u0433"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-8]":{"starter_content":true,"value":{"type":"post_type","object":"page","object_id":15,"position":3,"nav_menu_term_id":-5,"title":"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"twentytwenty::nav_menu_locations[expanded]":{"starter_content":true,"value":-5,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu[-9]":{"starter_content":true,"value":{"name":"\\u041c\\u0435\\u043d\\u044e \\u0441\\u043e\\u0446\\u0438\\u0430\\u043b\\u044c\\u043d\\u044b\\u0445 \\u0441\\u0441\\u044b\\u043b\\u043e\\u043a"},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-9]":{"starter_content":true,"value":{"title":"Yelp","url":"https:\\/\\/www.yelp.com","position":0,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-10]":{"starter_content":true,"value":{"title":"Facebook","url":"https:\\/\\/www.facebook.com\\/wordpress","position":1,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-11]":{"starter_content":true,"value":{"title":"Twitter","url":"https:\\/\\/twitter.com\\/wordpress","position":2,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-12]":{"starter_content":true,"value":{"title":"Instagram","url":"https:\\/\\/www.instagram.com\\/explore\\/tags\\/wordcamp\\/","position":3,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"nav_menu_item[-13]":{"starter_content":true,"value":{"title":"Email","url":"mailto:wordpress@example.com","position":4,"nav_menu_term_id":-9,"object_id":0},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"twentytwenty::nav_menu_locations[social]":{"starter_content":true,"value":-9,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"show_on_front":{"starter_content":true,"value":"page","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"page_on_front":{"starter_content":true,"value":13,"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"},"page_for_posts":{"starter_content":true,"value":16,"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 06:08:52"}}', '', '', 'auto-draft', 'closed', 'closed', '', 'c599b434-e0c8-40da-b7e3-c06714dd7886', '', '', '2022-07-06 09:08:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/warwara.first_stage.local/?p=17', 0, 'customize_changeset', '', 0),
(19, 1, '2022-07-06 09:24:04', '2022-07-06 06:24:04', '<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"fontSize":"small"} -->\n<p class="has-small-font-size" style="font-style:normal;font-weight:600">Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Нашествие мертвецов!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-07-06 09:24:04', '2022-07-06 06:24:04', '', 1, 'http://localhost/warwara.first_stage.local/?p=19', 0, 'revision', '', 0),
(20, 1, '2022-07-06 10:35:48', '2022-07-06 07:35:48', '{"blogname":{"value":"\\u041d\\u041e\\u0412\\u041e\\u0421\\u0422\\u041d\\u041e\\u0419 \\u041e\\u0422\\u0414\\u0415\\u041b","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 07:35:08"},"blogdescription":{"value":"\\u0420\\u0438\\u0442\\u043e\\u0440\\u0438\\u043a\\u0430 \\u0438 \\u0434\\u0440\\u0430\\u043c\\u0430 \\u0432 \\u043e\\u0434\\u043d\\u043e\\u043c \\u0444\\u043b\\u0430\\u043a\\u043e\\u043d\\u0435","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 07:35:48"}}', '', '', 'trash', 'closed', 'closed', '', '584acf17-4258-4602-8e9b-5e303e8f76a0', '', '', '2022-07-06 10:35:48', '2022-07-06 07:35:48', '', 0, 'http://localhost/warwara.first_stage.local/?p=20', 0, 'customize_changeset', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 3, 0),
(5, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'category', '', 0, 1),
(4, 4, 'category', '', 3, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'twentytwentytwo', 'twentytwentytwo', 0),
(3, 'Новости', 'news', 0),
(4, 'Новости для партнеров', 'partnership', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Warwara7416'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"5d43c1feb05f5b678c9c0b66c1451a4f75df8900c262391b943f739e7e9851c6";a:4:{s:10:"expiration";i:1658296481;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36";s:5:"login";i:1657086881;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Warwara7416', '$P$BLUH.y1gBovKplGZ9lwEfYpN.IMEKG0', 'warwara7416', 'pavel.002@mail.ru', 'http://localhost/warwara.first_stage.local', '2022-07-06 05:53:00', '', 0, 'Warwara7416') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

